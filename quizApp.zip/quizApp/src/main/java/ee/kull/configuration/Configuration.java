package ee.kull.configuration;

public class Configuration {
    protected String dbHost = "localhost";
    protected String dbPort = "5432";
    protected String dbUser = "postgres";
    protected String dbPass = "qwer778899";
    protected String dbName = "quiz_app";

}
